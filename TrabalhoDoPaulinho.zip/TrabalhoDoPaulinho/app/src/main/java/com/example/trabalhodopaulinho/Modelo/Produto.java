package com.example.trabalhodopaulinho.Modelo;

public class Produto {
    private String descricao;
    private String nomeProduto;
    private int codigo;
    private double valorUnitario;

    private String edProdutosEscolhidos;

    public Produto(String descricao) {

    }

    public Produto() {

    }

    public Produto(String descricao, String nomeProduto, int codigo, double valorUnitario, String edProdutosEscolhidos) {
        this.descricao = descricao;
        this.nomeProduto = nomeProduto;
        this.codigo = codigo;
        this.valorUnitario = valorUnitario;
        this.edProdutosEscolhidos = edProdutosEscolhidos;
    }

    public String getEdProdutosEscolhidos() {
        return edProdutosEscolhidos;
    }

    public void setEdProdutosEscolhidos(String edProdutosEscolhidos) {
        this.edProdutosEscolhidos = edProdutosEscolhidos;
    }

    public String getDescricao() {
        return descricao;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public double getValorUnitario() {
        return valorUnitario;
    }


    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setValorUnitario(double valorUnitario) {
        this.valorUnitario = valorUnitario;
    }

    public String getNomeProduto() {return nomeProduto;}

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }
}
