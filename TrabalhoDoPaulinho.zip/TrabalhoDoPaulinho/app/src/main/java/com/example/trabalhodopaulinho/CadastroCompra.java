package com.example.trabalhodopaulinho;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.trabalhodopaulinho.Modelo.Compras;
import com.example.trabalhodopaulinho.Modelo.Produto;

public class CadastroCompra extends AppCompatActivity {

    private EditText edProdutosEscolhidos;
    private EditText edQuantidade;

    private EditText edSelecionarCliente;
    private RadioButton rbAVista;

    private RadioButton rbParcelado;
    private RadioGroup rgSitemaRadioGroup;
    private Button btAdicionar;
    private EditText edProdutos;
    private TextView tvProdutosEscolhidos;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_compra);


        edQuantidade = findViewById(R.id.edQuantidade);
        edProdutosEscolhidos = findViewById(R.id.edProdutosEscolhidos);
        edSelecionarCliente = findViewById(R.id.edSelecionarCliente);
        rbAVista = findViewById(R.id.rbAVista);
        rbParcelado = findViewById(R.id.rbParcelado);
        rgSitemaRadioGroup = findViewById(R.id.rgSitemaRadioGroup);
        btAdicionar = findViewById(R.id.btAdicionar);



        btAdicionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adicionarCompra();

            }
        });


        rgSitemaRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rbAVista) {

                } else if (checkedId == R.id.rbParcelado) {

                }
            }
        });
    }


    private void adicionarCompra() {
        if (edProdutosEscolhidos.getText().toString().isEmpty()) {
            edProdutosEscolhidos.setError("Informe pelo menos um produto");
            return;
        }
        if (edQuantidade.getText().toString().isEmpty()) {
            edQuantidade.setError("A quantidade deve ser maior do que 0");
            return;
        }

        Compras compras = new Compras();
        compras.setNome(edProdutosEscolhidos.getText().toString());
        Produto produto = new Produto();
        produto.getValorUnitario();


        Controller.getInstance().salvarProdutoEscolhido(compras);

        Toast.makeText(CadastroCompra.this,
                "Produto Adicionado a lista",
                Toast.LENGTH_LONG).show();

        this.finish();


    }


    private void atualizarListaCompras(){
        String texto = "";
        for (Compras compras : Controller.getInstance().retornarCompras()) {
            texto += "Produto: "+compras.getNome()+" - "+compras.getQuantidade()+"\n";
        }
        tvProdutosEscolhidos.setText(texto);
    }
}




















/*   @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_padrao, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.mnSalvar) {//chamar o metodo de salvar
            salvarTurma();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void salvarTurma() {

        if(rbAnual.isChecked()){
            Toast.makeText(this,
                    "vc selecionou o Anual",
                    Toast.LENGTH_LONG).show();
        }
        if(rbSemestral.isChecked()){
            Toast.makeText(this,
                    "vc selecionou o Semestral",
                    Toast.LENGTH_LONG).show();
        }*/