package com.example.trabalhodopaulinho;

import com.example.trabalhodopaulinho.Modelo.Cliente;
import com.example.trabalhodopaulinho.Modelo.Compras;
import com.example.trabalhodopaulinho.Modelo.Produto;

import java.util.ArrayList;

public class Controller {




    private static Controller  instancia;


    private ArrayList<Cliente> listaCliente;
    private ArrayList<Produto> listaProduto;

    private ArrayList<Compras> listaCompras;



    public static Controller getInstance(){
        if(instancia == null) {
            return instancia = new Controller();
        }else {
            return instancia;
        }
    }

    private Controller(){
        listaCliente = new ArrayList<>();
        listaProduto = new ArrayList<>();
        listaCompras = new ArrayList<>();
    }

    public void salvarProduto(Produto produto){ listaProduto.add(produto);
    }
    public void salvarProdutoEscolhido(Compras compra){
        listaCompras.add(compra);
    }
    public ArrayList<Produto> retornarProduto() {
        return listaProduto;
    }

    public void salvarCliente(Cliente cliente){ listaCliente.add(cliente);
    }
    public ArrayList<Cliente> retornarCliente() {
        return listaCliente;
    }
    public void salvarCompras(Compras compras){ listaCompras.add(compras);
    }
    public ArrayList<Compras> retornarCompras() {
        return listaCompras;
    }








}
