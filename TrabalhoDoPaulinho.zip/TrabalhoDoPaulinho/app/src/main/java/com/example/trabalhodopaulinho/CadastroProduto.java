package com.example.trabalhodopaulinho;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.trabalhodopaulinho.Modelo.Cliente;
import com.example.trabalhodopaulinho.Modelo.Produto;

public class CadastroProduto extends AppCompatActivity {


    private EditText edNomeProduto;

    private EditText edCodigoProduto;
    private EditText edDescricaoProduto;

    private EditText edValorUnitario;

    private Button btSalvarProduto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_produto);


        edCodigoProduto = findViewById(R.id.edCodigoProduto);
        edNomeProduto = findViewById(R.id.edNomeProduto);
        edDescricaoProduto = findViewById(R.id.edDescricaoProduto);
        edValorUnitario = findViewById(R.id.edValorUnitario);
        btSalvarProduto = findViewById(R.id.btSalvarProduto);

        atualizarListaProdutos();

        btSalvarProduto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarProduto();
            }


        });
    }

        private void salvarProduto() {
            if(edNomeProduto.getText().toString().isEmpty()){
                edNomeProduto.setError("O campo NOME DO PRODUTO é obrigatorio!");
                return;
            }
            if(edDescricaoProduto.getText().toString().isEmpty()){
                edDescricaoProduto.setError("O campo DESCRIÇÃO é obrigatorio!");
                return;
            }
            if(edValorUnitario.getText().toString().isEmpty()){
                edValorUnitario.setError("O campo VALOR é obrigatorio!");
                return;
            }
            if(edCodigoProduto.getText().toString().isEmpty()){
                edCodigoProduto.setError("O campo CÓDIGO é obrigatorio!");
                return;
            }
            Produto produto = new Produto();
            produto.setCodigo(Integer.parseInt(edCodigoProduto.getText().toString()));
            produto.setNomeProduto(edNomeProduto.getText().toString());
            produto.setDescricao(edDescricaoProduto.getText().toString());
            produto.setValorUnitario(Double.parseDouble(edValorUnitario.getText().toString()));

            Controller.getInstance().salvarProduto(produto);

            Toast.makeText(CadastroProduto.this,
                    "Produto cadastrado com Sucesso!!",
                    Toast.LENGTH_LONG).show();

            this.finish();
        }

    private void atualizarListaProdutos(){
        String texto = "";
        for (Produto produto : Controller.getInstance().retornarProduto()) {
            texto += "PRODUTO: "+produto.getNomeProduto()+" - "+produto.getValorUnitario()+"\n";
        }

    }


    }
