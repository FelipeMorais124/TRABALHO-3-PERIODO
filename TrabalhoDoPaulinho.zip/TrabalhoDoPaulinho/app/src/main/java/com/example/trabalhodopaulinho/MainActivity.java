package com.example.trabalhodopaulinho;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btCadastroProduto;

    private Button btCadastroClientes;
    private Button btCadastroCompras;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btCadastroProduto = findViewById(R.id.btCadastroProduto);
        btCadastroClientes= findViewById(R.id.btCadastroClientes);
        btCadastroCompras = findViewById(R.id.btCadastroCompras);


        btCadastroCompras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrtirActivity(CadastroCompra.class);
            }
        });

    btCadastroClientes.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) { abrtirActivity(CadastrarCliente.class);

        }
    });

    btCadastroProduto.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) { abrtirActivity(CadastroProduto.class);

        }
    });

    }



    private void abrtirActivity(Class<?> activity) {
        Intent intent = new Intent(MainActivity.this, activity);
        startActivity(intent);
    }


}

